 onmessage = function(messageFromMainThread){
     console.log("Within Worker thread : "+ messageFromMainThread.data);
    var myArray = [];
    
        for(var i=0;i<4000;i++){
         myArray[i]= [];
         for(var j =0;j<2000;j++){
             myArray[i][j] = Math.random();
         }
        }

        console.log(window.document)

        postMessage(myArray); // post the data to the main thread
 }
 
 
 

